//
//  ViewController.swift
//  HelloWorld
//
//  Created by Estudiante on 7/11/16.
//  Copyright © 2016 Test. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textField: UITextField!
    
    @IBOutlet weak var lblMeal: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func ClickButton(sender: UIButton) {
        print("The name is: \(textField.text)")
        lblMeal.text = "Laboratorio 4"
    }
    
    

}

